/*! fuxi - v1.34.0 - 2021-06-01 */(function () {
    'use strict';

    // instanciação dos módulos
    var selectboxtreeModule = angular.module('fxselectboxtree', ['fxtree']);
    
    selectboxtreeModule.factory('fxselectboxtreeService', ['$http', '$q', function ($http, $q) {

        var defaultLanguage, currentLanguage;
        defaultLanguage = currentLanguage = 'en';

        var locales, defaultLocales;
        locales = defaultLocales = {
            'en': {                
                'PLACEHOLDER-SEARCH': 'search...',
                'PLACEHOLDER-ELEMENT': 'select...',
                'MESSAGE-EMPTY-DATA': 'empty data...',
                'MESSAGE-LOADING': 'loading...',
                'REQUEST-ERROR-MSG': 'error loading data!',
                'REQUEST-EMPTY-DATA': 'No results found',
                'REQUEST-SEARCHING': 'Searching...',
                'REQUEST-INITIAL-SEARCH': 'Enter {0} character{1}',
                'CHARACTER-PLURAL-SUFFIX': 's'
            },
            'pt': {                
                'PLACEHOLDER-SEARCH': 'pesquisar...',
                'PLACEHOLDER-ELEMENT': 'selecione...',
                'MESSAGE-EMPTY-DATA': 'sem registos!',
                'MESSAGE-LOADING': 'a carregar...',
                'REQUEST-ERROR-MSG': 'erro ao carregar os dados!',
                'REQUEST-EMPTY-DATA': 'Nenhum resultado encontrado',
                'REQUEST-SEARCHING': 'A pesquisar...',
                'REQUEST-INITIAL-SEARCH': 'Introduza {0} caracter{1}',
                'CHARACTER-PLURAL-SUFFIX': 'es'
            }
        };
        var getRequest = function (url, params) {
            var deferred = $q.defer();
            $http.get(url, { params: params }).success(function (data) {
                deferred.resolve(data);
            }).error(function (data, status, headers, config) {
                deferred.reject({data:data, status:status, headers:headers, config:config});
            });

            return deferred;            
        },
        abortRequest = function (deferred) {
            if (deferred) {
                deferred.resolve('aborted');
            }
        };

        return {
            setCurrentLanguage: function (newCurrentLanguage) {
                if (angular.isDefined(newCurrentLanguage))
                {
                    currentLanguage = newCurrentLanguage;
                }
            },

            getCurrentLanguage: function () {
                return currentLanguage;
            },

            loadCustomLocales: function (customLocales) {
                locales = $.extend(true, defaultLocales, customLocales);
            },

            setLabelByKey: function (key, text) {
                locales[currentLanguage][key] = text;
            },

            getLocale: function (key, lng) {
                var str = (locales[lng]) ? locales[lng][key] : locales[defaultLanguage][key];
                var args = Array.prototype.slice.call(arguments, 2);
                if (args.length > 0) {
                    return str.replace(/\{(\d+)\}/g, function (match, index) {
                        return args[index] || '';
                    });
                } else {
                    return str;
                }
            },

            getRequest: getRequest,
            abortRequest: abortRequest
        };
    }]);

    // filter
    selectboxtreeModule.filter('selectboxtreeLocal', ['$compile', 'fxselectboxtreeService', function ($compile, selectboxtreeServices) {
        return function (key, lang, numValue) {
            var str = selectboxtreeServices.getLocale(key, lang);
            if (!isNaN(numValue)) {
                str = $compile(str);
            }

            return str;
        };
    }]);
}
());
(function () {
    'use strict';
    // instanciação dos módulos
    var selectBoxModule = angular.module('fxselectboxtree');
    
    selectBoxModule.controller('SelectBoxTreeController', ['$scope', '$timeout', 'fxselectboxtreeService', 'treeServices',
        function ($scope, $timeout, fxselectboxtreeService, treeServices) {
            var ctrl = this;
            ctrl.elementsSelected = [];
            ctrl.isTreeLoaded = false;
            ctrl.selectBoxDropActive = false;
            ctrl.dropdownLoaded = false;
            ctrl.resetPosition = 0;
            ctrl.disabled = true;
            ctrl.skipTreeNodeEvent = 0; // count used to skip the select node event from the nwTree
            ctrl.skipTreeNodeNotificationEvent = 0; //count used to check if notification is to be broadcasted or not

            ctrl.inputLoading = false;
            ctrl.resultsSize = -1;
            ctrl.selectBoxTreeData = [];
            ctrl.searchField = '';
            ctrl.remoteSearch = false;
            ctrl.submitted = false;

            ctrl.processAjaxTree = function () {
                if (ctrl.demandMode === 'onInstantiation') {
                    ctrl.loadTree();
                } else {
                    ctrl.disabled = false;
                }
            };
            /*jshint camelcase: false */

            ctrl.applyInitSelection = function (skipTreeNodeEvent, treeObj) {
                var i, selection = ctrl.selectBoxTreeInitSelectedValues.slice(0), label;

                if (!ctrl.loadHasEmpty && treeObj && !ctrl.remoteSearch) {
                    for (i = 0; i < selection.length; i++) {
                        treeObj.open_node(selection[i].id);
                        if (skipTreeNodeEvent) {
                            ctrl.skipTreeNodeEvent++;
                        }
                        treeObj.select_node(selection[i].id);

                        if (selection[i].label) {
                            label = selection[i].label;
                        } else if (ctrl.fullLabel) {
							label = treeObj.get_path(selection[i].id, ctrl.fullLabelParser);
                        } else {
                            label = treeObj.get_node(selection[i].id).text || "undefined";
                        }

						selection[i].label = label; // treeObj.get_node(selection[i].id).text;
                    }
                }

                if (selection.length > 0) {
                    ctrl.elementsSelected = selection.slice(0);
                }
            };
            /*jshint camelcase: true */

            ctrl.hideDropdown = function () {               
                ctrl.selectBoxDropActive = false;
                ctrl.dropdownLoaded = false;
            };

            ctrl.openDropdown = function () {
                if (ctrl.readOnly) return;
                ctrl.searchField = '';
                if (ctrl.remoteSearch) {
                    ctrl.cleanTreeNodes();
                    ctrl.inputLoading = false;
                    ctrl.resultsSize = -1;
                    
                    ctrl.applyNewInitialSearchRequirementLabel();
                }else{
                    treeServices.getTree(ctrl.selectBoxTreeIdComponent).tree.search('');
                }
                ctrl.selectBoxDropActive = true;
                $timeout(function () {                    
                    ctrl.setFocusSearch();
                });
            };
            ctrl.setFocusSearch = function () {
                focus($(ctrl.selectBoxTreeSearchInputElement));
            };

            ctrl.triggerDropDown = function () {
                if (ctrl.disabled) return;

                if (ctrl.demandMode === 'onDemand' && !ctrl.isTreeLoaded) {
                    ctrl.disabled = true;
                    ctrl.loadTree();
                    return;
                }

                if (ctrl.isTreeLoaded) {
                    if (ctrl.selectBoxDropActive) {
                        return ctrl.hideDropdown();
                    }
                    ctrl.openDropdown();
                }
            };

            ctrl.getAdditionalTreePlugins = function () {
                var plugins = ['search','fxsearchmatch'];

                if (ctrl.selectBoxTreeMultiValues) {
                    plugins.push('checkbox');
                }

                return plugins;
            };

            ctrl.getAdditionalTreePluginsConfiguration = function () {
                /*jshint camelcase: false */
                return [
                    {
                        key: 'search',
                        value: {
                            show_only_matches: true
                        }
                    },
                    {
                        key: 'checkbox',
                        value: {
                            three_state: false
                        }
                    }
                ];
                /*jshint camelcase: false */
            };

            ctrl.getAdditionalTreeCoreConfiguration = function () {
                return [
                    {
                        key: 'themes',
                        value: {
                            name: 'fuxi',
                            icons: false
                        }
                    },
                    {
                        key: 'multiple',
                        value: ctrl.selectBoxTreeMultiValues
                    },
                    {
                        key: 'check_callback',
                        value: true
                    }
                ];
            };

            ctrl.applyNewSelection = function (selectedNodes, skipHideTree) {
                //ctrl.elementsSelected = selectedNodes;
                if (ctrl.remoteSearch && ctrl.selectBoxTreeMultiValues) {
                    // #NS devolve os elementos q estão no array mas q não estão na tree
                    var aux = [], id;
                    for (var i = 0; i < ctrl.elementsSelected.length; i++) {
                        if (!ctrl.idExistOnTree(ctrl.elementsSelected[i].id)) {
                            aux.push(ctrl.elementsSelected[i]);
                        }
                    }
                    ctrl.elementsSelected = aux.concat(selectedNodes);
                }
                else { ctrl.elementsSelected = selectedNodes; }

                if (!ctrl.selectBoxTreeMultiValues && !skipHideTree) {
                    $timeout(function () {
                        ctrl.hideDropdown();
                    });
                }
            };

            // function to set a new selection based on the viewValue
            ctrl.setNewSelectionModel = function (viewValue) {
                var ids = viewValue.split(','),
                    selectedNodes,
                    filteredIds = [];

                $.each(ids, function (idx, elem) {
                    if (elem) {
                        filteredIds.push(elem);
                    }
                });

                ctrl.clearSelection();
                ctrl.reflectIdsOnTree(filteredIds);

                selectedNodes = ctrl.fillSelectionArrayBasedOnIds(filteredIds);
                ctrl.applyNewSelection(selectedNodes.slice(0), true);
            };

            ctrl.removeSelectedElementById = function (id) {
                var i;

                for (i = 0; i < ctrl.elementsSelected.length; i++) {
                    if (ctrl.elementsSelected[i].id === id) {
                        ctrl.elementsSelected.splice(i, 1);
                        break;
                    }
                }
            };

            ctrl.reflectChangesOnModel = function () {
                var finalValue = '', i;

                if (ctrl.elementsSelected.length > 0) {
                    finalValue = [];

                    for (i = 0; i < ctrl.elementsSelected.length; i++) {
                        finalValue.push(ctrl.elementsSelected[i].id);
                    }
                    finalValue = finalValue.join(',');
                }
                return finalValue;
            };

            ctrl.notifyNewEvent = function (event, data) {
                $scope.$emit(event, data);
            };

            ctrl.clearSelection = function () {
                ctrl.skipTreeNodeNotificationEvent += ctrl.elementsSelected.length;
                while (ctrl.elementsSelected.length > 0) {
                    ctrl.deselectElement(ctrl.elementsSelected[0].id);
                }
            };

            $scope.$on('selectBoxTree::setDefaultValues', function (event, data) {
                if (!data || (data && data.id === ctrl.selectBoxTreeIdComponent)) {
                    ctrl.clearSelection();
                    ctrl.skipTreeNodeNotificationEvent += ctrl.selectBoxTreeInitSelectedValues.length;
                    ctrl.applyInitSelection(false, treeServices.getTree(ctrl.selectBoxTreeIdComponent).tree);
                }

            });
                     
            
            ctrl.validate = function () {
                ctrl.isValid = ctrl.getModelCtrl().$valid || (ctrl.getModelCtrl().$invalid && !ctrl.submitted && ctrl.getModelCtrl().$pristine);
            };

            ctrl.isModelDifferentFromInitialValues = function () {
                var i, initSelection = ctrl.selectBoxTreeInitSelectedValues.slice(0), selection = [];

                for (i = 0; i < initSelection.length; i++) {
                    selection.push(initSelection[i].id);
                }

                return selection.join(',') !== ctrl.getModelValue();
            };
            
            ctrl.applyRemoteSearch = function (searchParam, treeObj) {

                ctrl.cleanTreeNodes();
                ctrl.resultsSize = -1;
                ctrl.resetPosition++;

                if (ctrl.timerForInputDelay) {
                    $timeout.cancel(ctrl.timerForInputDelay);
                }

                ctrl.timerForInputDelay = $timeout(function () {
                    var params;
                    ctrl.hasRequestError = false;
                    if (searchParam && searchParam.length > 2) {
                        ctrl.inputLoading = true;

                        params = ctrl.urlParams || {};
                        params[ctrl.urlParams.fxSearchkey] = searchParam;

                        fxselectboxtreeService.abortRequest(ctrl.deferredObject);

                        ctrl.deferredObject = fxselectboxtreeService.getRequest(ctrl.url, params);

                        ctrl.deferredObject.promise.then(function (result) {
                            var i, results = result.data;

                            ctrl.resetPosition++;
                            ctrl.resultsSize = 0;

                            if (results) {
                                ctrl.cleanTreeNodes();
                                for (i = 0; i < results.length; i++) {
                                    ctrl.createRootNode(results[i]);
                                }
                                // #NS 
                                var fIds = [];
                                $.each(ctrl.elementsSelected, function (idx, elem) {
                                    if (elem) {
                                        fIds.push(elem.id);
                                    }
                                });
                                ctrl.reflectIdsOnTree(fIds);

                                ctrl.resultsSize = results.length;
                                ctrl.resetPosition++;

                                // #NS call tree search
                                if (treeObj) treeObj.search(searchParam);
                            }
                            $timeout(function () {
                                ctrl.inputLoading = false;
                            }, 500);
                        }, function (error) {
                            ctrl.inputLoading = false;
                            console.log("error: ", error);
                            ctrl.hasRequestError = true;
                        });
                    }
                }, ctrl.writeInterval);

            };

            ctrl.SetDisabled = function () {
                ctrl.disabled = true;
                ctrl.hideDropdown();
            };
            ctrl.SetEnabled= function () {
                ctrl.disabled = false;
            };

            function focus($el) {
                if ($el[0] === document.activeElement) return;

                /* set the focus in a 0 timeout - that way the focus is set after the processing
                    of the current event has finished - which seems like the only reliable way
                    to set focus */
                window.setTimeout(function () {
                    var el = $el[0], pos = $el.val().length, range;

                    $el.focus();

                    /* make sure el received focus so we do not error out when trying to manipulate the caret.
                        sometimes modals or others listeners may steal it after its set */
                    var isVisible = (el.offsetWidth > 0 || el.offsetHeight > 0);
                    if (isVisible && el === document.activeElement) {

                        /* after the focus is set move the caret to the end, necessary when we val()
                            just before setting focus */
                        if (el.setSelectionRange) {
                            el.setSelectionRange(pos, pos);
                        }
                        else if (el.createTextRange) {
                            range = el.createTextRange();
                            range.collapse(false);
                            range.select();
                        }
                    }
                }, 0);
            };

        }]);
}
());
(function () {
    'use strict';

    // instanciação dos módulos
    var selectBoxModule = angular.module('fxselectboxtree');

    /**
    * Applies a title to a given element. If the title is an Array, the function converts it to a coma separated string.
    * @param {jQuery element} $element the element to apply the title
    * @param {String or Array} title the title to be applied
    */
    var updateElementTitle = function ($element, title) {
        var result = '', sep = '';
        if (Array.isArray(title)) {
            if (title.length > 0) {
                title.map(function (val) {
                    result += sep + val;
                    sep = ', ';
                });
            }
        } else {
            result = title;
        }
        $element.attr('title', result);
    };


    selectBoxModule.directive('fxSelectBoxTree', ['$timeout', '$compile', '$http', 'fxselectboxtreeService',
            function ($timeout, $compile, $http, fxselectboxtreeService) {

                var updateSelectBoxElementTitle = function ($element, selectedVals) {
                    if (!selectedVals) {
                        updateElementTitle($element, '');
                    } else {
                        updateElementTitle($element, selectedVals.map(function (val) {
                            return val.label;
                        }).sort());
                    }
                };

                return {
                    restrict: 'A',
                    //scope: true,
                    scope: {
                        selectBoxTreeLanguage: '@selectBoxTreeLanguage'
                    },
                    controller: 'SelectBoxTreeController',
                    controllerAs: 'selectBoxTreeCtrl',
                    transclude: true,
                    priority: 2,
                    require: 'fxSelectBoxTree',
                    templateUrl: 'partials/selectboxtree.html',
                    link: function (scope, element, attrs, fxCtrl) {
                        var ngModelCtrl = fxCtrl.getModelCtrl();
                        var oldValue;

                        //console.log("selectBoxTreeLanguage: " + scope.selectBoxTreeLanguage);
                        var initializeSelectBoxTree = function () {

                            // set current language to the service
                            fxselectboxtreeService.setCurrentLanguage(scope.selectBoxTreeLanguage);
                            var selectBoxTreeLanguageKeyValues = (attrs.selectBoxTreeLanguageCustomKeys) ? jQuery.parseJSON(attrs.selectBoxTreeLanguageCustomKeys.replace(/'/g, "\"")) : null;
                            if (selectBoxTreeLanguageKeyValues) {
                                angular.forEach(selectBoxTreeLanguageKeyValues, function (value, key) {
                                    fxselectboxtreeService.setLabelByKey(key, value);
                                });
                            }

                            fxCtrl.selectBoxTreeInitSelectedValues = (attrs.selectBoxTreeSelectedValues) ? jQuery.parseJSON(attrs.selectBoxTreeSelectedValues) : [];
                            fxCtrl.selectBoxTreeId = attrs.id;
                            fxCtrl.selectBoxTreeIdComponent = 'select_box_tree_component_' + fxCtrl.selectBoxTreeId;

                            fxCtrl.dataIsEmpty = false;

                            fxCtrl.readOnly = attrs.hasOwnProperty('selectBoxTreeReadOnly');
                            fxCtrl.disabled = true;
                            fxCtrl.fullWidth = attrs.hasOwnProperty('selectBoxTreeFullWidth');
                            fxCtrl.selectBoxTreeMultiValues = attrs.hasOwnProperty('selectBoxTreeMultiValues');
                            fxCtrl.isValid = true;
                            fxCtrl.loadHasEmpty = attrs.hasOwnProperty('selectBoxTreeLoadHasEmpty');

                            fxCtrl.fullLabel = attrs.hasOwnProperty('selectBoxTreeFullLabel');
                            fxCtrl.urlParams = (attrs.selectBoxTreeUrlParams) ? jQuery.parseJSON(attrs.selectBoxTreeUrlParams.replace(/'/g, "\"")) : { fxSearchkey: "qs" };
                            if (!fxCtrl.urlParams["fxSearchkey"]) fxCtrl.urlParams["fxSearchkey"] = "qs";

                            fxCtrl.fullLabelParser = attrs.selectBoxTreeFullLabelParser || " , ";
                            fxCtrl.writeInterval = attrs.selectBoxTreeWriteInterval || 300;
                            fxCtrl.hasRequestError = false;

                            fxCtrl.submittedEventName = attrs.selectBoxTreeSubmittedEventName || "selectBoxTree::formSubmitted";

                            fxCtrl.disabledBrowserContextmenu = attrs.selectBoxTreeDisabledBrowserContextmenu || false;

                            fxCtrl.additionalClasses = {
                                'fx-ms-container-active': fxCtrl.selectBoxDropActive,
                                'fx-ms-dropdown-open': fxCtrl.selectBoxDropActive
                            };

                            fxCtrl.getSelectBoxTreeElement = function () {
                                return element.get(0);
                            };

                            fxCtrl.applyNewInitialSearchRequirementLabel = function () {
                                var length = 3 - fxCtrl.searchField.length;

                                var label = fxselectboxtreeService.getLocale('REQUEST-INITIAL-SEARCH', scope.selectBoxTreeLanguage, length, (length > 1) ? fxselectboxtreeService.getLocale('CHARACTER-PLURAL-SUFFIX', scope.selectBoxTreeLanguage) : '');
                                fxCtrl.initialSearchRequirementLabel = label;
                            };

                            if (!fxCtrl.readOnly) {
                                if (attrs.selectBoxTreeData) {
                                    fxCtrl.selectBoxTreeData = jQuery.parseJSON(attrs.selectBoxTreeData);
                                    fxCtrl.loadTree();
                                } else {
                                    fxCtrl.demandMode = attrs.selectBoxTreeDemandMode;
                                    fxCtrl.ajaxUrl = true;
                                    fxCtrl.setAjaxUrlOnTree(attrs.selectBoxTreeUrl);
                                    fxCtrl.remoteSearch = attrs.hasOwnProperty('selectBoxTreeRemoteSearch');

                                    if (fxCtrl.remoteSearch) {
                                        fxCtrl.url = attrs.selectBoxTreeUrl;
                                        fxCtrl.applyNewInitialSearchRequirementLabel();
                                        fxCtrl.loadTree();
                                    } else {
                                        fxCtrl.processAjaxTree();
                                    }
                                }
                            } else {
                                if (fxCtrl.loadHasEmpty) {
                                    fxCtrl.loadTree();
                                }
                                else {
                                    fxCtrl.applyInitSelection(true);
                                }
                            }

                            fxCtrl.deselectElement = function (id, event) {
                                fxCtrl.removeSelectedElementById(id);
                                fxCtrl.removeSelectedElementTreeById(id);

                                if (fxCtrl.remoteSearch) {
                                    //fxCtrl.setNewSelectionModel('');
                                    // #NS reflect changes on model
                                    ngModelCtrl.$setViewValue(fxCtrl.reflectChangesOnModel());
                                }

                                if (event) {
                                    event.stopPropagation();
                                }
                            };

                            // #NS Este código é executado demasiadas vezes, está a fazer-se watch a um array...                            
                            scope.$watch('selectBoxTreeCtrl.elementsSelected', function () {
                                if (!fxCtrl.disabled) {
                                    ngModelCtrl.$setViewValue(fxCtrl.reflectChangesOnModel());
                                }
                                updateSelectBoxElementTitle(element, fxCtrl.elementsSelected);
                            });

                            ngModelCtrl.$viewChangeListeners.push(function () {
                                var newValue = ngModelCtrl.$modelValue;
                                if (!fxCtrl.readOnly && !fxCtrl.remoteSearch && typeof newValue !== 'undefined' && newValue !== oldValue) {

                                    fxCtrl.setNewSelectionModel(newValue.toString());

                                    updateSelectBoxElementTitle(element, fxCtrl.elementsSelected);
                                    $timeout(function () {
                                        fxCtrl.resetPosition++;
                                    })
                                };
                                oldValue = ngModelCtrl.$modelValue;
                            });

                            // #NS este bind não está muito correcto, pois falha quando queremos setar multiplos valores... foi criado novo evento "setSelectedValues"
                            scope.$on('selectBoxTree::setSelectSearchValue', function (event, params) {
                                if (params && params.name === attrs.id) {

                                    fxCtrl.applyNewSelection([{
                                        id: params.value.id,
                                        label: params.value.value
                                    }]);

                                    updateSelectBoxElementTitle(element, fxCtrl.elementsSelected);
                                }
                            });

                            //#NS Criado método para os multivalores, devido a q o método anterior não o permite (manter a retrocompatibilidade)
                            scope.$on('selectBoxTree::setSelectedValues', function (event, params) {
                                if (params && params.name === attrs.id) {

                                    fxCtrl.applyNewSelection(params.value);

                                    updateSelectBoxElementTitle(element, fxCtrl.elementsSelected);
                                }
                            });


                            // #NS 
                            scope.$on(fxCtrl.submittedEventName, function (event, data) {
                                $timeout(function () {
                                    fxCtrl.submitted = true;
                                    fxCtrl.validate();
                                });
                            });

                        };


                        initializeSelectBoxTree();


                        fxCtrl.getModelValue = function () {
                            return ngModelCtrl.$viewValue;
                        };
                    }
                };
            }]);

    selectBoxModule.directive('fxSelectBoxTreeComponent', ['treeServices', '$timeout',
        function (treeServices, $timeout) {
            return {
                restrict: 'A',
                require: ['fxTree', '^fxSelectBoxTree'],
                priority: 3,
                link: function (scope, element, attrs, ctrls) {
                    var treeCtrl = ctrls[0],
                        selectBoxTreeCtrl = ctrls[1],
                        treeObj;

                    selectBoxTreeCtrl.setAjaxUrlOnTree = function (url) {
                        attrs.treeLoadUrl = url;
                    };

                    treeCtrl.treeAfterLoad = function () {
                        treeObj = treeServices.getTree(attrs.id).tree;

                        if (selectBoxTreeCtrl.getModelValue() && selectBoxTreeCtrl.isModelDifferentFromInitialValues()) { // if model set, ignore default selection
                            selectBoxTreeCtrl.setNewSelectionModel(selectBoxTreeCtrl.getModelValue());
                        } else {
                            selectBoxTreeCtrl.firstModelSet = true;
                            selectBoxTreeCtrl.applyInitSelection(true, treeObj);
                        }


                        selectBoxTreeCtrl.disabled = false;
                        if (!selectBoxTreeCtrl.remoteSearch && selectBoxTreeCtrl.demandMode === 'onDemand') {
                            selectBoxTreeCtrl.openDropdown();
                        }
                        selectBoxTreeCtrl.isTreeLoaded = true;
                        selectBoxTreeCtrl.notifyNewEvent('selectBoxTree::loaded', attrs.id);
                    };

                    treeCtrl.onRequestSuccess = function (tree, data) {
                        selectBoxTreeCtrl.dataIsEmpty = treeCtrl.dataIsEmpty;
                        // 
                        $timeout(function () {
                            selectBoxTreeCtrl.loading = false;
                        }, 300);
                    };

                    selectBoxTreeCtrl.loadTree = function () {
                        var additionalPlugins, additionalPluginsConfiguration, additionalCoreConfiguration;

                        if (!selectBoxTreeCtrl.isTreeLoaded) {
                            additionalPlugins = selectBoxTreeCtrl.getAdditionalTreePlugins();
                            additionalPluginsConfiguration = selectBoxTreeCtrl.getAdditionalTreePluginsConfiguration();
                            additionalCoreConfiguration = selectBoxTreeCtrl.getAdditionalTreeCoreConfiguration();

                            if (selectBoxTreeCtrl.remoteSearch || selectBoxTreeCtrl.loadHasEmpty) {
                                treeCtrl.callInitializeTreeEmpty(additionalPlugins, additionalPluginsConfiguration, additionalCoreConfiguration);
                            } else {
                                if (selectBoxTreeCtrl.ajaxUrl) {
                                    selectBoxTreeCtrl.loading = true;
                                    treeCtrl.callInitializeTreeWithRest(additionalPlugins, additionalPluginsConfiguration, additionalCoreConfiguration);
                                } else {
                                    treeCtrl.callInitializeTreeWithJSON(selectBoxTreeCtrl.selectBoxTreeData,
                                                                        additionalPlugins,
                                                                        additionalPluginsConfiguration,
                                                                        additionalCoreConfiguration);

                                    selectBoxTreeCtrl.dataIsEmpty = treeCtrl.dataIsEmpty;
                                }
                            }
                        }
                    };
                    /*jshint camelcase: false */
                    treeCtrl.treeElementClicked = function (ev, data) {
                        var selectedNodes, i, selected = treeObj.get_selected();
                        if (selectBoxTreeCtrl.skipTreeNodeEvent > 0) {
                            selectBoxTreeCtrl.skipTreeNodeEvent--;
                        } else {
                            if (ev.type === 'select_node') {
                                data.instance.open_node(data.node);
                            }

                            selectedNodes = selectBoxTreeCtrl.fillSelectionArrayBasedOnIds(selected);
                            selectBoxTreeCtrl.applyNewSelection(selectedNodes, selectBoxTreeCtrl.inputLoading);

                            if (selectBoxTreeCtrl.skipTreeNodeNotificationEvent === 0) {
                                $timeout(function () {
                                    selectBoxTreeCtrl.notifyNewEvent('selectBoxTree::optionsSelected', {
                                        id: attrs.id,
                                        valuesSelected: selectBoxTreeCtrl.elementsSelected
                                    });
                                });
                            } else {
                                selectBoxTreeCtrl.skipTreeNodeNotificationEvent--;
                            }
                        }
                    };

                    treeCtrl.treeAfterOpenNode = function (ev, data) {
                        selectBoxTreeCtrl.resetPosition++;
                    };
                    treeCtrl.treeAfterCloseNode = function (ev, data) {
                        selectBoxTreeCtrl.resetPosition++;
                    };

                    selectBoxTreeCtrl.removeSelectedElementTreeById = function (id) {
                        treeObj.deselect_node(id);
                    };

                    selectBoxTreeCtrl.fillSelectionArrayBasedOnIds = function (ids) {
                        var selectedNodes = [], i, label;

                        if (treeObj) {
                            for (i = 0; i < ids.length; i++) {

                                if (selectBoxTreeCtrl.fullLabel) {
                                    label = treeObj.get_path(ids[i], selectBoxTreeCtrl.fullLabelParser);
                                } else {
									label = treeObj.get_node(ids[i]).text || "undefined";
                                }

                                selectedNodes.push({
                                    id: ids[i],
                                    label: label
                                });
                            }
                        }

                        return selectedNodes;
                    };

                    selectBoxTreeCtrl.reflectIdsOnTree = function (ids) {
                        var i,
                            id;

                        if (treeObj) {
                            for (i = 0; i < ids.length; i++) {
                                id = ids[i];
                                treeObj.select_node(id);
                                //treeObj.open_node(id);
                            }
                        }
                    };

                    selectBoxTreeCtrl.idExistOnTree = function (id) {
                        if (treeObj) {
                            var node = treeObj.get_node(id);
                            return !!node;
                        }

                    };

                    /*jshint camelcase: true */
                    selectBoxTreeCtrl.applySearch = function (event) {
                        event.stopImmediatePropagation();
                        if (selectBoxTreeCtrl.remoteSearch) {
                            selectBoxTreeCtrl.applyNewInitialSearchRequirementLabel();
                            selectBoxTreeCtrl.applyRemoteSearch(selectBoxTreeCtrl.searchField, treeObj);
                        } else {
                            treeObj.search(selectBoxTreeCtrl.searchField);
                        }

                    };

                    /*jshint camelcase: false */
                    selectBoxTreeCtrl.cleanTreeNodes = function () {
                        if (!treeObj) return;
                        var nodesToDelete = $(element).find('li');
                        var ids = nodesToDelete.map(function (index) {
                            return this.id;
                        }).get();
                        treeObj.delete_node(ids);
                    };

                    selectBoxTreeCtrl.createRootNode = function (node) {
                        treeObj.create_node('#', node, 'last');
                    };
                    /*jshint camelcase: true */
                }
            };
        }]);

    selectBoxModule.directive('fxSelectBoxTreeDropdown', ['$document', '$timeout', '$log', function ($document, $timeout, $log) {
        var uniqueId = 1;
        function installKeyUpChangeEvent(element) {
            var key = "keyup-change-value";
            element.on("keydown", function () {
                if ($.data(element, key) === undefined) {
                    $.data(element, key, element.val());
                }
            });
            element.on("keyup", function () {
                var val = $.data(element, key);
                if (val !== undefined && element.val() !== val) {
                    $.removeData(element, key);
                    element.trigger("keyup-change");
                }
            });
        };
        return {
            restrict: 'A',
            require: '^fxSelectBoxTree',
            link: function (scope, element, attrs, ctrl) {

                var evtName = "mousedown.ms.outsideClick." + uniqueId++;
                $timeout(function () {
                    var uniqSearchID = ctrl.getSelectBoxTreeElement().id + '-selectBoxTreeSearchInput';

                    ctrl.selectBoxTreeSearchInputElement = element.find('#selectBoxTreeSearchInput');
                    ctrl.selectBoxTreeSearchInputElement.attr('id', uniqSearchID);

                    installKeyUpChangeEvent(ctrl.selectBoxTreeSearchInputElement);
                    ctrl.selectBoxTreeSearchInputElement.on("keyup-change input paste", handleSearch);
                });

                var hsTimeout = 0;
                var handleSearch = function (ev) {
                    clearTimeout(hsTimeout);
                    hsTimeout = setTimeout(function () {
                        ctrl.applySearch(ev);
                    }, 250);
                };

                var onDocumentClick = function (event) {
                    $timeout(function () {
                        if (!ctrl.selectBoxDropActive) return;

                        var isChild = $.contains(element.get(0), event.target);
                        var isOwner = $.contains(ctrl.getSelectBoxTreeElement(), event.target);
                        if (!isChild && !isOwner) {
                            ctrl.hideDropdown();
                        }
                    });
                };

                var appendElementTo = function (to) {
                    $(element).appendTo(to);
                };

                var elementPosition = function () {
                    ctrl.dropdownLoaded = false;
                    scope.$apply();

                    var treeElmId = ctrl.getSelectBoxTreeElement().id;
                    var $dropdown = $(element);

                    var $container = $(ctrl.getSelectBoxTreeElement()).find(".fx-ms");
                    var $window = $(window);

                    var isCurrentlyAbove = $dropdown.hasClass('fx-ms-dropdown-above');

                    var newDirection = null;

                    var position = $container.position();
                    var offset = $container.offset();
                    var container = {
                        height: $container.outerHeight(false),
                        width: $container.outerWidth(false),
                        top: offset.top
                    };
                    container.bottom = offset.bottom = offset.top + container.height

                    var bb = parseInt($container.css("border-bottom-width")) || 0;

                    var dropdown = {
                        height: $dropdown.outerHeight(false)
                    };

                    var viewport = {
                        top: $window.scrollTop(),
                        bottom: $window.scrollTop() + $window.height()
                    };

                    var height = container.height;
                    var dropTop = offset.top + height;
                    var dropHeight = dropdown.height;
                    var windowHeight = $window.height();
                    var viewportBottom = $window.scrollTop() + windowHeight;

                    var enoughRoomBelow = dropTop + dropHeight <= viewportBottom,
                        enoughRoomAbove = (offset.top - dropHeight) >= $window.scrollTop();

                    var css = {
                        left: offset.left,
                        top: container.bottom - bb,
                        width: container.width
                    };

                    if (isCurrentlyAbove) {
                        if (!enoughRoomAbove && enoughRoomBelow) {
                            newDirection = "below";
                        }
                    } else {
                        if (!enoughRoomBelow && enoughRoomAbove) {
                            newDirection = "above";
                        }
                    }

                    if (!enoughRoomAbove && !enoughRoomBelow) {
                        newDirection = "below";
                    }

                    if (newDirection == 'above' || (isCurrentlyAbove && newDirection !== 'below')) {
                        css.top = container.top - dropdown.height;
                    }

                    if (newDirection != null) {
                        $dropdown
                          .removeClass('fx-ms-dropdown-below fx-ms-dropdown-above')
                          .addClass('fx-ms-dropdown-' + newDirection);
                        $container
                          .removeClass('fx-ms-container-below fx-ms-container-above')
                          .addClass('fx-ms-container-' + newDirection);
                    }

                    $dropdown.css(css);
                    ctrl.dropdownLoaded = true;
                };

                scope.$watch(
                    function () {
                        return ctrl.selectBoxDropActive;
                    },
                    function (newValue, oldValue) {
                        if (newValue !== oldValue) {
                            if (newValue) {
                                $timeout(function () {
                                    appendElementTo('body');
                                    elementPosition();
                                    $document.on(evtName, onDocumentClick);

                                    var $container = $(ctrl.getSelectBoxTreeElement()).find(".fx-ms");

                                    $container.closest(".fx-overflow").on("wheel", function () { return false; });
                                });
                            }
                            else {
                                var $container = $(ctrl.getSelectBoxTreeElement()).find(".fx-ms");
                                appendElementTo($container);
                                $document.off(evtName);
                                $container.closest(".fx-overflow").off("wheel");
                            }
                        }
                    }
                );

                scope.$watch(
                    function () {
                        return ctrl.resetPosition;
                    },
                    function (newValue, oldValue) {
                        if (newValue !== oldValue) {
                            $timeout(function () {
                                elementPosition();
                                //console.log("input !loading");
                            });
                        }
                    }
                );

                // on resize window...
                var resizeEvt;
                $(window).on('resize', function () {
                    console.log("resized...");
                    clearTimeout(resizeEvt);
                    resizeEvt = setTimeout(function () {
                        if (!ctrl.selectBoxDropActive) return;
                        //code to do after window is resized
                        ctrl.resetPosition++;
                        scope.$apply();
                    }, 100);
                });

                // on modal scroll
                $timeout(function () {
                    var scrollEvt;
                    $(ctrl.getSelectBoxTreeElement()).closest('.modal').scroll(function () {
                        clearTimeout(scrollEvt);
                        scrollEvt = setTimeout(function () {
                            if (!ctrl.selectBoxDropActive) return;
                            //code to do after modal scroll
                            ctrl.resetPosition++;
                            scope.$apply();
                        }, 100);

                    });
                }, 0);

                element.on('$destroy', function () {
                    $document.off(evtName);
                });
            }
        };
    }]);

    selectBoxModule.directive('fxSelectBoxTreeTarget', ['$timeout', function ($timeout) {
        return {
            restrict: 'A',
            require: ['^fxSelectBoxTree', 'ngModel'],
            link: function (scope, element, attrs, ctrl) {
                var fxCtrl = ctrl[0];
                var ngModelCtrl = ctrl[1];

                fxCtrl.getModelCtrl = function () {
                    return ngModelCtrl;
                };

                $timeout(function () {
                    //for focus                    
                    var inpFocusser = $(element);
                    inpFocusser.prop("readonly", true).addClass('sr-only');
                    var containerFocusser = $(fxCtrl.getSelectBoxTreeElement());

                    inpFocusser.on("focus", function () {
                        containerFocusser.find('.fx-ms-focusser').addClass("fx-ms-has-focus");
                    }).on("blur", function () {
                        containerFocusser.find('.fx-ms-focusser').removeClass("fx-ms-has-focus");
                    }).on("keydown", function (e) {
                        // ENTER
                        if (e.which == 13) {

                            if (e.altKey || e.ctrlKey || e.shiftKey || e.metaKey) return;

                            fxCtrl.triggerDropDown();
                            //e.preventDefault(); 
                            e.stopPropagation();
                        }
                    });
                    // ---------------------------

                    scope.$watch(
                        function () {
                            return ngModelCtrl.$valid;
                        },
                        function (newValue, oldValue) {
                            if (newValue !== oldValue) {
                                fxCtrl.validate();
                            }
                        });

                })

            }
        };
    }]);

    selectBoxModule.directive('fxElementAlwaysPristine', [function () {
        return {
            restrict: 'A',
            priority: 2000,
            require: 'ngModel',
            link: function (scope, element, attrs, ctrl) {
                ctrl.$pristine = false;
            }
        };
    }]);
}
());



angular.module('fxselectboxtree').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('partials/selectboxtree.html',
    "<div data-ng-class=\"{'fx-ms-wrapper': !selectBoxTreeCtrl.readOnly && !selectBoxTreeCtrl.disabled,\r" +
    "\n" +
    "                     'fx-ms-wrapper-disabled': selectBoxTreeCtrl.readOnly || selectBoxTreeCtrl.disabled,\r" +
    "\n" +
    "                     'fx-ms-wrapper-opened': selectBoxTreeCtrl.selectBoxDropActive,\r" +
    "\n" +
    "                     'full-width': selectBoxTreeCtrl.fullWidth,\r" +
    "\n" +
    "                     'fx-ms-has-error': !selectBoxTreeCtrl.isValid}\" class=\"fx-ms fx-ms-focusser\"><div data-for=types data-ng-disabled=selectBoxTreeCtrl.disabled data-ng-class=\"{'fx-ms-container-active': selectBoxTreeCtrl.selectBoxDropActive,\r" +
    "\n" +
    "                        'fx-ms-selection-container': !selectBoxTreeCtrl.selectBoxTreeMultiValues,\r" +
    "\n" +
    "                        'fx-ms-selection-container-multi': selectBoxTreeCtrl.selectBoxTreeMultiValues}\" data-ng-click=selectBoxTreeCtrl.triggerDropDown()><div class=fx-ms-selection><ul class=fx-ms-choices><li class=fx-ms-choice-placeholder ng-if=selectBoxTreeCtrl.loading>{{'MESSAGE-LOADING' | selectboxtreeLocal:selectBoxTreeLanguage}}</li><li class=fx-ms-choice-placeholder ng-if=\"selectBoxTreeCtrl.elementsSelected.length <= 0 && !selectBoxTreeCtrl.dataIsEmpty && !selectBoxTreeCtrl.loading\">{{'PLACEHOLDER-ELEMENT' | selectboxtreeLocal:selectBoxTreeLanguage}}</li><li class=fx-ms-choice-placeholder ng-if=\"selectBoxTreeCtrl.dataIsEmpty && !selectBoxTreeCtrl.loading\">{{'MESSAGE-EMPTY-DATA' | selectboxtreeLocal:selectBoxTreeLanguage}}</li><li data-ng-repeat=\"element in selectBoxTreeCtrl.elementsSelected | orderBy:'label'\" class=fx-ms-search-choice ng-class=\"{'fx-ms-unique-choice': !selectBoxTreeCtrl.selectBoxTreeMultiValues}\"><div ng-if=selectBoxTreeCtrl.selectBoxTreeMultiValues><a data-ng-hide=\"selectBoxTreeCtrl.readOnly == true || selectBoxTreeCtrl.disabled == true\" data-ng-click=\"selectBoxTreeCtrl.deselectElement(element.id, $event)\" class=fx-ms-search-choice-close><i class=\"glyphicon glyphicon-remove\"></i> </a><span>{{element.label}}</span></div><div ng-if=!selectBoxTreeCtrl.selectBoxTreeMultiValues class=fx-ms-unique-choice-wrapper><span class=fx-ms-unique-choice-title>{{element.label}} </span><a data-ng-hide=\"selectBoxTreeCtrl.readOnly == true || selectBoxTreeCtrl.disabled == true\" data-ng-click=\"selectBoxTreeCtrl.deselectElement(element.id, $event)\" class=fx-ms-search-choice-close><i class=\"glyphicon glyphicon-remove\"></i></a></div></li></ul></div><span class=fx-ms-expand-arrow data-ng-class=\"{'fx-ms-expanded-arrow':selectBoxTreeCtrl.selectBoxDropActive}\"><i class=caret></i></span></div><div class=fx-ms-dropdown id={{selectBoxTreeCtrl.selectBoxTreeId}}-selectBoxTreeDropdown data-ng-class=\"{ 'fx-ms-has-error': !selectBoxTreeCtrl.isValid, 'fx-out-off-screen': !selectBoxTreeCtrl.dropdownLoaded }\" data-ng-style=selectBoxTreeCtrl.selectBoxDropStylingConf data-ng-show=selectBoxTreeCtrl.selectBoxDropActive data-fx-select-box-tree-dropdown><div><div class=\"form-group fx-search-input\"><div class=fx-pos-rel><button class=\"glyphicon glyphicon-search\" data-ng-show=!selectBoxTreeCtrl.inputLoading></button> <span data-ng-show=selectBoxTreeCtrl.inputLoading class=fx-ms-loading></span> <input class=\"form-control input-sm full-width\" id=selectBoxTreeSearchInput placeholder=\"{{'PLACEHOLDER-SEARCH' | selectboxtreeLocal:selectBoxTreeLanguage}}\" data-ng-model=selectBoxTreeCtrl.searchField data-fx-element-always-pristine></div><div data-ng-show=selectBoxTreeCtrl.hasRequestError class=fx-ms-request-error>{{'REQUEST-ERROR-MSG' | selectboxtreeLocal:selectBoxTreeLanguage}}</div><ul data-ng-show=\"selectBoxTreeCtrl.remoteSearch && !selectBoxTreeCtrl.hasRequestError && selectBoxTreeCtrl.resultsSize <= 0\" class=fx-ms-search-hint><li data-ng-show=\"selectBoxTreeCtrl.resultsSize === -1 && !selectBoxTreeCtrl.inputLoading && selectBoxTreeCtrl.searchField.length < 3\">{{selectBoxTreeCtrl.initialSearchRequirementLabel}}</li><li data-ng-show=\"selectBoxTreeCtrl.inputLoading || selectBoxTreeCtrl.searchField.length > 2 && selectBoxTreeCtrl.resultsSize === -1\">{{'REQUEST-SEARCHING' | selectboxtreeLocal:selectBoxTreeLanguage}}</li><li data-ng-show=\"selectBoxTreeCtrl.resultsSize === 0\">{{'REQUEST-EMPTY-DATA' | selectboxtreeLocal:selectBoxTreeLanguage}}</li></ul></div><div id={{selectBoxTreeCtrl.selectBoxTreeIdComponent}} data-fx-tree data-fx-select-box-tree-component data-fx-select-box-tree-disabled-browser-contextmenu={{selectBoxTreeCtrl.disabledBrowserContextmenu}} class=fx-ms-dropdown-tree></div></div></div><div ng-transclude></div></div>"
  );

}]);

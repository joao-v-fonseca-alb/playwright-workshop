﻿
$(document).ready(function () {
    "use strict";

    // check if jquery layout is on page
    if (!$.layout) { console.log("jquery layout is not included on page!"); return false; }

    var iTips = {
        Open: "maximizar sidebar"
        , Close: "minimizar sidebar"
        , Resize: "redimensionar"
        , Slide: "maximizar acima do conteúdo"
		, Pin: "Pin"
		, Unpin: "Un-Pin"
		, noRoomToOpen: "Não há espaço suficiente para mostrar o painel."	// alert if user tries to open a pane that cannot
		, minSizeWarning: "Painel atingiu seu tamanho mínimo."	// displays in browser statusbar
		, maxSizeWarning: "Painel atingiu seu tamanho máximo."	// ditto
    };

    var _tips = $.layout.defaults.panes.tips;
    var _itips = $.extend(true, {}, _tips, iTips);
    $.layout.defaults.panes.tips = _itips;

})

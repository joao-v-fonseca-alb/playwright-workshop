/*! fuxi - v1.34.0 - 2021-06-01 */(function () {
    'use strict';
    // instanciação dos módulos
    var treeModule = angular.module('fxtree',[]);

    treeModule.factory('treeServices', function () {
        var trees = [];
        return {
            prepareJSONData: function (data, additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
                var defaultConf = {
                    core: {
                        data: data
                    },
                    plugins: []
                };

                if (additionalPlugins) {
                    defaultConf.plugins = defaultConf.plugins.concat(additionalPlugins);
                }

                if (defaultConf.plugins.length === 0) {
                    delete defaultConf.plugins;
                }

                if (additionalPluginConfigurations) {
                    additionalPluginConfigurations.forEach(function (elem) {
                        defaultConf[elem.key] = elem.value;
                    });
                }

                if (additionalCoreConfigurations) {
                    additionalCoreConfigurations.forEach(function (elem) {
                        defaultConf.core[elem.key] = elem.value;
                    });
                }

                return defaultConf;
            },
            getTree: function (id) {
                var result = null;
                trees.forEach(function (value) {
                    if (value.id === id) {
                        result = value;
                    }
                });
                return result;
            },
            deleteTree: function (id) {
                var tree = this.getTree(id);
                if (tree) {
                    tree.tree.destroy();
                }
                trees = _.without(trees, _.findWhere(trees, { id: id }));
            },
            storeNewTree: function (id, tree, treeInfo) {
                this.deleteTree(id);
                trees.push({
                    id: id,
                    tree: tree,
                    treeInfo: treeInfo
                });
            },
            updateTree: function (id, tree, treeInfo) {
                trees.forEach(function (value) {
                    if (value.id === id) {
                        value.tree = tree || value.tree;
                        value.treeInfo = treeInfo || value.treeInfo;
                    }
                });
            },
            existsTree: function (id) {
                var result = false;
                trees.forEach(function (value) {
                    if (value.id === id) {
                        result = true;
                    }
                });
                return result;
            }
        };
    });
}
());
(function () {
    'use strict';
    // instanciação dos módulos
    var treeModule = angular.module('fxtree');

    treeModule.controller('TreeController', ['$scope', function ($scope) {
        var ref = this;

        //expected to be overrided
        ref.treeElementClicked = function (ev, data) { };
        ref.treeAfterOpenNode = function (ev, data) { };
        ref.treeAfterCloseNode = function (ev, data) { };
        ref.treeAfterLoad = function (tree) { };
        // DEPRECATED ----------------------------------------------
        ref.onRestRequestError = function (data, status) { };
        // ---------------------------------------------------------
        ref.onRequestError = function (data, status) { };
        ref.onRequestSuccess = function (tree, data) { };
        
        /////

        ref.initializeTreeWithJSON = function (element, data, additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
        };
        ref.initializeTreeWithRest = function (additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
        };
        ref.initializeTreeEmpty = function (additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
        };

        ref.setInitializeTreeWithJSON = function (fn) {
            ref.initializeTreeWithJSON = fn;
        };
        ref.callInitializeTreeWithJSON = function (data, additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
            return ref.initializeTreeWithJSON(data, additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations);
        };

        ref.setInitializeTreeWithRest = function (fn) {
            ref.initializeTreeWithRest = fn;
        };
        ref.callInitializeTreeWithRest = function (additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
            return ref.initializeTreeWithRest(additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations);
        };

        ref.setInitializeTreeEmpty = function (fn) {
            ref.initializeTreeEmpty= fn;
        };
        ref.callInitializeTreeEmpty = function (additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
            return ref.initializeTreeEmpty(additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations);
        };

    }]);
}
());
(function () {
    'use strict';
    // instanciação dos módulos
    var treeModule = angular.module('fxtree');

    treeModule.directive('fxTree', ['$http', 'treeServices', '$timeout', function ($http, treeServices, $timeout) {
        return {
            restrict: 'A',
            controller: 'TreeController',
            link: function (scope, element, attrs, ctrl) {

                ctrl.dataIsEmpty = false;

                function bindContextmenu(defaultConfiguration) {
                    // if tree hasn't contextmenu plugin disable right click
                    if (ctrl.disabledBrowserContextmenu === "true" && $.inArray('contextmenu', defaultConfiguration.plugins) === -1) {
                        ctrl.tree.bind('contextmenu', '.jstree-anchor', function (e) {
                            e.preventDefault();
                            e.stopImmediatePropagation();
                            return false;
                        });
                    }
                }

                ctrl.setInitializeTreeWithJSON(function (data, additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
                    ctrl.dataIsEmpty = (data.length === 0);
                    if (ctrl.dataIsEmpty) return;

                    var defaultConfiguration = treeServices.prepareJSONData(data,
                                                                   additionalPlugins,
                                                                   additionalPluginConfigurations,
                                                                   additionalCoreConfigurations);



                    $timeout(function () {
                        ctrl.disabledBrowserContextmenu = attrs.fxSelectBoxTreeDisabledBrowserContextmenu || false;

                        ctrl.tree = element.jstree(defaultConfiguration).on('loaded.jstree', function () {
                            $timeout(function () {
                                treeServices.storeNewTree(attrs.id, element.jstree(true));
                                ctrl.treeAfterLoad(element);
                            });

                        });

                        ctrl.tree.bind('select_node.jstree deselect_node.jstree', function (ev, data) {
                            $timeout(function () {
                                ctrl.treeElementClicked(ev, data);
                            });
                        });
                        ctrl.tree.bind('after_open.jstree', function (ev, data) {
                            $timeout(function () {
                                ctrl.treeAfterOpenNode(ev, data);
                            });
                        });
                        ctrl.tree.bind('after_close.jstree', function (ev, data) {
                            $timeout(function () {
                                ctrl.treeAfterCloseNode(ev, data);
                            });
                        });

                        ctrl.tree.bind("click.jstree", function (ev, data) {
                            return false;
                        });

                        bindContextmenu(defaultConfiguration);

                    });
                });

                ctrl.setInitializeTreeWithRest(function (additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {
                    if (typeof attrs.treeLoadUrl !== 'undefined') {
                        // Simple GET request example :
                        $http.get(attrs.treeLoadUrl).
                          success(function (data, status, headers, config) {
                              ctrl.dataIsEmpty = (data.data.length === 0);

                              if (!ctrl.dataIsEmpty) {
                                  var defaultConfiguration = treeServices.prepareJSONData(data.data,
                                      additionalPlugins,
                                      additionalPluginConfigurations,
                                      additionalCoreConfigurations);

                                  ctrl.disabledBrowserContextmenu = attrs.fxSelectBoxTreeDisabledBrowserContextmenu || false;

                                  ctrl.tree = element.jstree(defaultConfiguration).on('loaded.jstree', function () {
                                      $timeout(function () {
                                          treeServices.storeNewTree(attrs.id, element.jstree(true));
                                          ctrl.treeAfterLoad(element);
                                      });
                                  });

                                  ctrl.tree.bind('select_node.jstree deselect_node.jstree', function (ev, data) {
                                      $timeout(function () {
                                          ctrl.treeElementClicked(ev, data);
                                      });
                                  });
                                  ctrl.tree.bind('after_open.jstree', function (ev, data) {
                                      $timeout(function () {
                                          ctrl.treeAfterOpenNode(ev, data);
                                      });
                                  });
                                  ctrl.tree.bind('after_close.jstree', function (ev, data) {
                                      $timeout(function () {
                                          ctrl.treeAfterCloseNode(ev, data);
                                      });
                                  });

                                  ctrl.tree.bind("click.jstree", function (ev, data) {
                                      return false;
                                  });

                                  bindContextmenu(defaultConfiguration);
                              }
                              ctrl.onRequestSuccess(ctrl.tree, data);
                          }).
                          error(function (data, status, headers, config) {
                              ctrl.onRequestError(data, status);
                              // DEPRECATED: para manter retrocompatibilidade
                              ctrl.onRestRequestError(data, status);
                          });
                    }
                });

                ctrl.setInitializeTreeEmpty(function (additionalPlugins, additionalPluginConfigurations, additionalCoreConfigurations) {

                    var defaultConfiguration = treeServices.prepareJSONData([], additionalPlugins,
                                                                   additionalPluginConfigurations,
                                                                   additionalCoreConfigurations);



                    $timeout(function () {
                        ctrl.disabledBrowserContextmenu = attrs.fxSelectBoxTreeDisabledBrowserContextmenu || false;

                        ctrl.tree = element.jstree(defaultConfiguration).on('loaded.jstree', function () {
                            $timeout(function () {
                                treeServices.storeNewTree(attrs.id, element.jstree(true));
                                ctrl.treeAfterLoad(element);
                            });

                        });

                        ctrl.tree.bind('select_node.jstree deselect_node.jstree', function (ev, data) {
                            $timeout(function () {
                                ctrl.treeElementClicked(ev, data);
                            });
                        });
                        ctrl.tree.bind('after_open.jstree', function (ev, data) {
                            $timeout(function () {
                                ctrl.treeAfterOpenNode(ev, data);
                            });
                        });
                        ctrl.tree.bind('after_close.jstree', function (ev, data) {
                            $timeout(function () {
                                ctrl.treeAfterCloseNode(ev, data);
                            });
                        });

                        ctrl.tree.bind("click.jstree", function (ev, data) {
                            return false;
                        });

                        bindContextmenu(defaultConfiguration);

                    });
                });

                scope.$on('$destroy', function () {
                    treeServices.deleteTree(attrs.id);
                });
            }
        };
    }]);
}
());
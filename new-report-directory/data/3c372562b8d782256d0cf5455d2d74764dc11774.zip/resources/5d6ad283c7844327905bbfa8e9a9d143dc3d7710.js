/* global jQuery */
// match a string on search
(function ($, undefined) {
    "use strict";
    var span = '<span class="fx-jstree-search-match">{TEXT}</span>';

    $.jstree.plugins.fxsearchmatch = function (options, parent) {

        this.bind = function () {
            parent.bind.call(this);
            this.element.on('search.jstree', function (e, data) {
                $.each(data.res, function (idx, id) {
                    var $nodeanchor = $("#" + id).children("a");
                    var h = $nodeanchor.html();
                    var orig = data.instance.get_node(id).text;
                    var str = data.str.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
                    var txt = orig.replace(new RegExp("(" + str + ")", "gi"), function (a, b) {
                        return span.replace(/{TEXT}/, b);
                    });
                    //console.log(txt);
                    var o = orig.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
                    var re = new RegExp(o, 'gi');
                    var rep = h.replace(re, txt);
                    $nodeanchor.html(rep);
                });
            });
            this.element.on('clear_search.jstree', function (e, data) {

                $.each(data.nodes, function (idx, node) {
                    var $nodeanchor = $(node).children("a");
                    var h = $nodeanchor.html();
                    var _span = span.replace(/{TEXT}/, '((?!<\/span>).*?)');
                    var txt = h.replace(new RegExp(_span, 'gi'), function (a, b) {
                        //console.log('clear: ', b);
                        return b;
                    });
                    $nodeanchor.html(txt);
                });
            });
        };
    };
})(jQuery);
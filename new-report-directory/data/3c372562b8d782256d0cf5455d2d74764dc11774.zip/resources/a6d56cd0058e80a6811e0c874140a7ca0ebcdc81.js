FUXI.Resources = {
	"Version" : "1.9.0 beta",
	"Splitter" : { 
		"MinimizeSidebar" : "minimizar\nsidebar", 
		"MaximizeSidebar" : "maximizar\nsidebar" 
	},
	"SliderTabs": {
        "RemoveTab": "remover tab"
	},
	"Common" : {
	    "EmptyInfo" : "Não tem informação definida"
	}
}